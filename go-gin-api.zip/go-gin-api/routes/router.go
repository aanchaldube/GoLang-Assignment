package routes

import (
    "github.com/gin-gonic/gin"
    "yourproject/handlers"
)

func RegisterRoutes(r *gin.Engine) {
    r.GET("/health", handlers.HealthCheck)
}
