# Go REST API with Gin and PostgreSQL

A RESTful API built with Go, Gin, and PostgreSQL using pgxpool.

## Features

- RESTful API with Gin
- PostgreSQL integration with pgxpool
- Secure password hashing
- Environment variable support

## Setup

1. Clone the repo
2. Run `go mod tidy`
3. Create `.env` file
4. Run `go run main.go`
5. Visit http://localhost:8080

## License

MIT
