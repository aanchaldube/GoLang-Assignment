package database

import (
    "context"
    "log"
    "os"
    "github.com/jackc/pgx/v4/pgxpool"
)

var DB *pgxpool.Pool

func ConnectDB() {
    var err error
    dbUrl := os.Getenv("DB_URL")
    DB, err = pgxpool.Connect(context.Background(), dbUrl)
    if err != nil {
        log.Fatal("Unable to connect to database: ", err)
    }
}
