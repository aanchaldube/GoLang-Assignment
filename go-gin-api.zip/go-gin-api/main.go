package main

import (
    "github.com/gin-gonic/gin"
    "log"
    "os"

    "yourproject/database"
    "yourproject/routes"
    "github.com/joho/godotenv"
)

func main() {
    if err := godotenv.Load(); err != nil {
        log.Fatal("Error loading .env file")
    }

    database.ConnectDB()
    router := gin.Default()
    routes.RegisterRoutes(router)

    port := os.Getenv("PORT")
    if port == "" {
        port = "8080"
    }

    router.Run(":" + port)
}
